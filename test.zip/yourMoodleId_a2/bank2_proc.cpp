//Jack Tolleson
#include "bank2.h"
#include <sqlite3.h>
#include <iostream>
#include <string>

#define DBNAME "bank2.db"


//adds money
int *b2_credit_1_svc(char *account, int amount, struct svc_req *rqstp) {
    static int result;
    sqlite3 *db;
    char *errMsg = nullptr;
    int rc;
    result = -1;

    rc = sqlite3_open(DBNAME, &db);
    if (rc) return &result;

    std::string sql = "CREATE TABLE IF NOT EXISTS ACCOUNTS (ACCOUNT TEXT PRIMARY KEY, BALANCE INT);";
rc = sqlite3_exec(db, sql.c_str(), nullptr, nullptr, &errMsg);
// Check error as before

sql = "INSERT OR IGNORE INTO ACCOUNTS (ACCOUNT, BALANCE) VALUES ('" + std::string(account) + "', 0);";
rc = sqlite3_exec(db, sql.c_str(), nullptr, nullptr, &errMsg);
// Check error as before

sql = "UPDATE ACCOUNTS SET BALANCE = BALANCE + " + std::to_string(amount) + " WHERE ACCOUNT = '" + std::string(account) + "';";
rc = sqlite3_exec(db, sql.c_str(), nullptr, nullptr, &errMsg);
    result = (rc == SQLITE_OK) ? 0 : -1;

    sqlite3_close(db);
    return &result;
}

//removes money
int *b2_debit_1_svc(char *account, int amount, struct svc_req *rqstp) {
    static int result;
    sqlite3 *db;
    char *errMsg = nullptr;
    int rc;
    result = -1;

    rc = sqlite3_open(DBNAME, &db);
    if (rc) return &result;

    std::string sql = "SELECT BALANCE FROM ACCOUNTS WHERE ACCOUNT = '" + std::string(account) + "';";
    sqlite3_stmt *stmt;
    rc = sqlite3_prepare_v2(db, sql.c_str(), -1, &stmt, nullptr);
    if (rc != SQLITE_OK) { sqlite3_close(db); return &result; }
    rc = sqlite3_step(stmt);
    if (rc != SQLITE_ROW) { sqlite3_finalize(stmt); sqlite3_close(db); return &result; }

    int balance = sqlite3_column_int(stmt, 0);
    sqlite3_finalize(stmt);

    if (balance < amount) { sqlite3_close(db); return &result; }
    sql = "UPDATE ACCOUNTS SET BALANCE = BALANCE - " + std::to_string(amount) + " WHERE ACCOUNT = '" + std::string(account) + "';";
    rc = sqlite3_exec(db, sql.c_str(), nullptr, nullptr, &errMsg);
    result = (rc == SQLITE_OK) ? 0 : -1;

    sqlite3_close(db);
    return &result;
}

