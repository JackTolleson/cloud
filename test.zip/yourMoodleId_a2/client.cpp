//Jack Tolleson
#include "virtual_bank.h"
#include <iostream>
#include <sstream>
#include <string>

int main(int argc, char **argv) {
    //determines if connection is successfull to virtual bank
    CLIENT *clnt = clnt_create("localhost", VIRTUAL_BANK_PROG, VIRTUAL_BANK_VERS, "tcp");
    if (clnt == nullptr) { std::cerr << "Cannot connect to virtual bank\n"; return 1; }
    //basic input reading where it determines which command to send to vb and sends an error if formatted wrong
    std::string line;
    std::cout << "> ";
    while (std::getline(std::cin, line)) {
        std::istringstream iss(line);
        std::string cmd, acc1, acc2;
        int amount;
        iss >> cmd;
        if (cmd == "credit") {
            iss >> acc1 >> amount;
            int *res = vb_credit_1((char*)acc1.c_str(), amount, clnt);
            std::cout << ((res && *res == 0) ? "Success" : "Error") << std::endl;
        } else if (cmd == "debit") {
            iss >> acc1 >> amount;
            int *res = vb_debit_1((char*)acc1.c_str(), amount, clnt);
            std::cout << ((res && *res == 0) ? "Success" : "Error") << std::endl;
        } else if (cmd == "transfer") {
            iss >> acc1 >> acc2 >> amount;
            int *res = vb_transfer_1((char*)acc1.c_str(), (char*)acc2.c_str(), amount, clnt);
            std::cout << ((res && *res == 0) ? "Success" : "Error") << std::endl;
        } else {
            std::cout << "Unknown command\n";
        }
        std::cout << "> ";
    }
    clnt_destroy(clnt);
    return 0;
}