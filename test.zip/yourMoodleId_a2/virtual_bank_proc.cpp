//Jack Tolleson
#include "virtual_bank.h"
#include "bank1.h"
#include "bank2.h"
#include <string.h>
#include <string>
#include <iostream>


//determines which bank to add money
int *vb_credit_1_svc(char *account, int amount, struct svc_req *rqstp) {
    static int result;
    CLIENT *bank_clnt = nullptr;
    if (account[0] == 'A') {
        bank_clnt = clnt_create("localhost", BANK1_PROG, BANK1_VERS, "tcp");
        if (bank_clnt) result = *b1_credit_1(account, amount, bank_clnt);
    } else if (account[0] == 'B') {
        bank_clnt = clnt_create("localhost", BANK2_PROG, BANK2_VERS, "tcp");
        if (bank_clnt) result = *b2_credit_1(account, amount, bank_clnt);
    } else {
        result = -1;
    }
    if (bank_clnt) clnt_destroy(bank_clnt);
    return &result;
}
//determines which bank to remove money
int *vb_debit_1_svc(char *account, int amount, struct svc_req *rqstp) {
    static int result;
    CLIENT *bank_clnt = nullptr;
    if (account[0] == 'A') {
        bank_clnt = clnt_create("localhost", BANK1_PROG, BANK1_VERS, "tcp");
        if (bank_clnt) result = *b1_debit_1(account, amount, bank_clnt);
    } else if (account[0] == 'B') {
        bank_clnt = clnt_create("localhost", BANK2_PROG, BANK2_VERS, "tcp");
        if (bank_clnt) result = *b2_debit_1(account, amount, bank_clnt);
    } else {
        result = -1;
    }
    if (bank_clnt) clnt_destroy(bank_clnt);
    return &result;
}

//determines which bank to remove money from and add money to. Will be the same amount for both
int *vb_transfer_1_svc(char *account1, char *account2, int amount, struct svc_req *rqstp) {
    static int result;
    result = -1;
    int debit_result = -1, credit_result = -1;
    CLIENT *from_clnt = nullptr, *to_clnt = nullptr;

    if (account1[0] == 'A') from_clnt = clnt_create("localhost", BANK1_PROG, BANK1_VERS, "tcp");
    else if (account1[0] == 'B') from_clnt = clnt_create("localhost", BANK2_PROG, BANK2_VERS, "tcp");

    if (account2[0] == 'A') to_clnt = clnt_create("localhost", BANK1_PROG, BANK1_VERS, "tcp");
    else if (account2[0] == 'B') to_clnt = clnt_create("localhost", BANK2_PROG, BANK2_VERS, "tcp");

    if (from_clnt && to_clnt) {
        if (account1[0] == 'A') debit_result = *b1_debit_1(account1, amount, from_clnt);
        else debit_result = *b2_debit_1(account1, amount, from_clnt);

        if (debit_result == 0) {
            if (account2[0] == 'A') credit_result = *b1_credit_1(account2, amount, to_clnt);
            else credit_result = *b2_credit_1(account2, amount, to_clnt);
            result = (credit_result == 0) ? 0 : -1;
        }
    }
    if (from_clnt) clnt_destroy(from_clnt);
    if (to_clnt) clnt_destroy(to_clnt);
    return &result;
}

